function anotherCard() {

}